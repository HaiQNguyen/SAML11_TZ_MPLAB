#include <atmel_start.h>
#include "Secure_functions/secure_console.h"
#include "cryptoauthlib.h"
#include "atca_host.h"

/* Define section ---------------------------------------------------*/

/* TZ_START_NS: Start address of non-secure application */
#define TZ_START_NS 0x00008000

#define CHECK_STATUS(s)										\
if(s != ATCA_SUCCESS) {										\
	printf("status code: 0x%x\r\n", s);						\
	printf("Error: Line %d in %s\r\n", __LINE__, __FILE__); \
	while(1);												\
}


/* Local variable section --------------------------------------------*/
ATCAIfaceCfg cfg_ateccx08a_i2c_host = {
	.iface_type				= ATCA_I2C_IFACE,
	.devtype				= ATECC508A,
	.atcai2c.slave_address	= 0xC2,
	.atcai2c.bus			= 1,
	.atcai2c.baud			= 400000,
	.wake_delay				= 800,
	.rx_retries				= 20,
	.cfg_data              = &I2C_0
};

ATCAIfaceCfg cfg_ateccx08a_i2c_remote = {
	.iface_type				= ATCA_I2C_IFACE,
	.devtype				= ATECC508A,
	.atcai2c.slave_address	= 0xC0,
	.atcai2c.bus			= 1,
	.atcai2c.baud			= 400000,
	.wake_delay				= 800,
	.rx_retries				= 20,
	.cfg_data              = &I2C_0
};


/* Local function prototype section ----------------------------------*/
void TestPorting(void);
void print_bytes(uint8_t * ptr, uint8_t length);

/* typedef for non-secure callback functions */
typedef void (*ns_funcptr_void) (void) __attribute__((cmse_nonsecure_call));

int main(void)
{
	/* Pointer to Non secure reset handler definition*/
	ns_funcptr_void NonSecure_ResetHandler;
	
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	/* Print Secure Hello world on the terminal window */
	secure_console_puts ("\n\r Secure Hello world !");
	
	TestPorting();
	
	/* - Set non-secure main stack (MSP_NS) */
	__TZ_set_MSP_NS(*((uint32_t *)(TZ_START_NS)));
	
	/* - Get non-secure reset handler */
	NonSecure_ResetHandler = (ns_funcptr_void)(*((uint32_t *)((TZ_START_NS) + 4U)));
	
	/* - Start Non-secure Application */
	NonSecure_ResetHandler();
	
	/* Replace with your application code */
	while (1) {
	}
}

void print_bytes(uint8_t * ptr, uint8_t length)
{
	
	uint8_t i = 0;
	uint8_t line_count = 0;
	for(;i < length; i++) {
		printf("0x%02x, ",ptr[i]);
		line_count++;
		if(line_count == 8) {
			printf("\r\n");
			line_count = 0;
		}
	}
	
	printf("\r\n");
}

void TestPorting(void)
{
	printf("Test Porting\r\n");
	
	volatile ATCA_STATUS status;
	uint8_t serial_number[ATCA_SERIAL_NUM_SIZE];
	
#if 0
	status = atcab_init( &cfg_ateccx08a_i2c_host );
	CHECK_STATUS(status);
	printf("Device init complete\n\r");

	/*Getting serial from host*/
	
	
	status = atcab_read_serial_number((uint8_t*)&serial_number);
	CHECK_STATUS(status);
	printf("Serial Number of host\r\n");
	print_bytes((uint8_t*)&serial_number, 9);
	printf("\r\n");
	
	delay_ms(2000);
#endif

	status = atcab_init( &cfg_ateccx08a_i2c_remote );
	CHECK_STATUS(status);
	status = atcab_read_serial_number((uint8_t*)&serial_number);
	CHECK_STATUS(status);
	printf("Serial Number of remote\r\n");
	print_bytes((uint8_t*)&serial_number, 9); printf("\r\n");
	
}
crypto directory - Purpose
===========================
This directory contains software implementations of cryptographic functions.
The functions at the base level are wrappers that will point to the final
implementations of the software crypto functions.


/*
 * secure_console.h
 *
 * Created: 13/05/2019 05:16:19
 *  Author: haing
 */ 


#ifndef SECURE_CONSOLE_H_
#define SECURE_CONSOLE_H_

#include <atmel_start.h>

/******************************************
* NAME : void secure_console_puts (uint8_t * string);
* DESCRIPTION : Display information comings from secure world (Color : green )
* PARAMETERS : uint8_t * string : address of the string to be displayed
* RETURN : None
*******************************************/

void secure_console_puts (uint8_t * string);
/******************************************
* NAME : void non_secure_console_puts (uint8_t * string);
* DESCRIPTION : Display information comings from secure gateways (Color : Red )
* PARAMETERS : uint8_t * string : address of the string to be displayed
* RETURN : None
*******************************************/
void non_secure_console_puts (uint8_t * string);


#endif /* SECURE_CONSOLE_H_ */
/*
 * secure_console.c
 *
 * Created: 13/05/2019 05:15:31
 *  Author: haing
 */ 

#include "Secure_functions/secure_console.h"

void secure_console_puts (uint8_t * string)
{
	/* Set display foreground color to green */
	printf("\033[0;32m");
	/* Print string on console */
	printf("%s", string);
}

void non_secure_console_puts (uint8_t * string)
{
	/* Set display foreground color to red */
	printf("\033[0;31m");
	/* Print string on console */
	printf("%s", string);
}
